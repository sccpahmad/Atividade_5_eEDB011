# dags/s3_raw_trusted_delivered.py
from __future__ import annotations
from datetime import timedelta
import io, os, re, unicodedata
import pendulum
import pandas as pd
from fuzzywuzzy import process, fuzz

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.models import Variable

# =========================================================
# Variáveis
# =========================================================
def _get_var(name: str, default: str = "") -> str:
    v = Variable.get(name, default_var=default)
    return v.strip() if isinstance(v, str) else v

def _as_bool(v: str, default: bool = False) -> bool:
    if v is None or v == "":
        return default
    return str(v).strip().lower() in {"1", "true", "yes", "y", "on"}

S3_BUCKET            = _get_var("S3_BUCKET")
RAW_PREFIX           = _get_var("RAW_PREFIX", "raw/")
TRUSTED_PREFIX       = _get_var("TRUSTED_PREFIX", "trusted/")
DELIVERED_PREFIX     = _get_var("DELIVERED_PREFIX", "delivered/")
OVERWRITE_TRUSTED    = _as_bool(_get_var("OVERWRITE_TRUSTED", "false"))
OVERWRITE_DELIVERED  = _as_bool(_get_var("OVERWRITE_DELIVERED", "false"))
DELIVERED_ONLY_NEW   = _as_bool(_get_var("DELIVERED_ONLY_NEW_FROM_TRUSTED", "true"))

# =========================================================
# Helpers
# =========================================================
def _copy_or_overwrite(hook, bucket, src_key, dst_key, overwrite=False):
    exists = hook.check_for_key(key=dst_key, bucket_name=bucket)
    if exists and not overwrite:
        return False
    if exists and overwrite:
        hook.delete_objects(bucket, keys=[dst_key])
    hook.copy_object(
        source_bucket_key=src_key,
        dest_bucket_key=dst_key,
        source_bucket_name=bucket,
        dest_bucket_name=bucket,
    )
    print(f"[COPY] {src_key} -> {dst_key}")
    return True

def _move_or_copy(hook, bucket, src_key, dst_key, overwrite=False):
    created = _copy_or_overwrite(hook, bucket, src_key, dst_key, overwrite=overwrite)
    return created

def _put_versioned_or_overwrite(s3: S3Hook, bucket: str, base_key: str, payload: bytes, overwrite: bool) -> str:
    """
    Tenta gravar em base_key. Se overwrite=False e a key já existir, grava com sufixo de timestamp.
    Retorna a key efetivamente usada.
    """
    if overwrite:
        s3.load_bytes(payload, key=base_key, bucket_name=bucket, replace=True)
        return base_key

    # Sem overwrite: versiona se existir
    if s3.check_for_key(key=base_key, bucket_name=bucket):
        ts = pendulum.now("America/Sao_Paulo").to_datetime_string().replace(":", "-").replace(" ", "_")
        name, ext = os.path.splitext(base_key)
        versioned_key = f"{name}_{ts}{ext}"
        s3.load_bytes(payload, key=versioned_key, bucket_name=bucket, replace=False)
        print(f"[S3] {base_key} já existia. Gravado como {versioned_key}")
        return versioned_key
    else:
        s3.load_bytes(payload, key=base_key, bucket_name=bucket, replace=False)
        return base_key

# =========================================================
# Funções utilitárias
# =========================================================
def limpar_nome(nome):
    if pd.isna(nome):
        return ''
    nome = unicodedata.normalize('NFKD', str(nome))
    nome = ''.join([c for c in nome if not unicodedata.combining(c)])
    nome = nome.upper()
    for palavra in ['S/A','S.A.','S.A','BANCO','FINANCEIRA','(BRASIL)','BRASIL','MULTIPLO','CREDITO',
                    'CREDITO, FINANCIAMENTO E INVESTIMENTOS','INSTITUICAO DE PAGAMENTO','(CONGLOMERADO)',
                    'MEDIUM','FINANCEIRO','CRED','SCFI','FINANCIAMENTO','INDUSTRIAL','GRUPO','SEGURO',
                    'BANK','INVESTIMENTOS','CFI','BS2',' - PRUDENCIAL','PRUDENCIAL','INVESTIMENTO',
                    'CAPITAL','SOCIEDADE','DE','- ',',','.',' ']:
        nome = nome.replace(palavra, '')
    return nome.strip()

def fuzzy_join(df_esquerda, df_direita, col_esquerda, col_direita, threshold=85):
    df_esquerda = df_esquerda.copy()
    df_direita  = df_direita.copy()
    df_esquerda['nome_normalizado'] = df_esquerda[col_esquerda].apply(limpar_nome)
    df_direita['nome_normalizado']  = df_direita[col_direita].apply(limpar_nome)
    mapa_direita = (df_direita.drop_duplicates(subset='nome_normalizado')
                    .set_index('nome_normalizado').to_dict('index'))
    def encontrar_match(nome):
        if not mapa_direita:
            return pd.Series(dtype='object')
        match = process.extractOne(nome, mapa_direita.keys(), scorer=fuzz.token_sort_ratio)
        if match and match[1] >= threshold:
            return pd.Series(mapa_direita[match[0]])
        return pd.Series({k: None for k in next(iter(mapa_direita.values())).keys()})
    df_matches = df_esquerda['nome_normalizado'].apply(encontrar_match)
    return pd.concat([df_esquerda, df_matches.add_prefix('ref_')], axis=1)

def trata_documento(val):
    if pd.isna(val):
        return None
    s = re.sub(r"\D", "", str(val))
    if not s:
        return None
    # CNPJ: 14 dígitos
    return s[-14:].zfill(14)

# =========================================================
# Data Quality (Great Expectations) - Helpers
# =========================================================
def _gx_expectations_for_reclamacoes(df):
    import great_expectations as ge
    gdf = ge.from_pandas(df)

    # Presença e formato de chaves
    if "instituição_financeira" in df.columns:
        gdf.expect_column_values_to_not_be_null("instituição_financeira")
    if "cnpj_if" in df.columns:
        gdf.expect_column_values_to_not_be_null("cnpj_if")
        gdf.expect_column_values_to_match_regex("cnpj_if", r"^\d{14}$")

    # Índice numérico plausível
    for cand in ["Índice", "Indice", "indice", "índice"]:
        if cand in df.columns:
            gdf.expect_column_values_to_be_between(cand, min_value=0, max_value=9999, mostly=0.99)

    # Trimestre ∈ {1,2,3,4}
    if "Trimestre" in df.columns:
        gdf.expect_column_values_to_be_in_set("Trimestre", {"1","2","3","4",1,2,3,4})

    # Colunas iniciando com "Quantidade" não-negativas
    for c in df.columns:
        if str(c).strip().lower().startswith("quantidade"):
            gdf.expect_column_values_to_be_between(c, min_value=0)

    return gdf.validate()

def _gx_expectations_for_delivered(df):
    import great_expectations as ge
    gdf = ge.from_pandas(df)

    # Chave de junção
    if "cnpj" in df.columns:
        gdf.expect_column_values_to_not_be_null("cnpj")
        gdf.expect_column_values_to_match_regex("cnpj", r"^\d{14}$")

    # Sanidade básica para possíveis métricas
    for col in df.columns:
        base = str(col).lower()
        if base.startswith("quantidade"):
            gdf.expect_column_values_to_be_between(col, min_value=0)
        if base in {"indice", "índice"}:
            gdf.expect_column_values_to_be_between(col, min_value=0, max_value=9999, mostly=0.99)

    return gdf.validate()

def _log_ge_failures(result: dict) -> None:
    """Imprime no log as expectativas que falharam, com pequena amostra."""
    fails = []
    reslist = result.get("results", []) if isinstance(result, dict) else getattr(result, "results", []) or []
    for r in reslist:
        if r.get("success") is False:
            cfg = r.get("expectation_config", {}) or {}
            kwargs = cfg.get("kwargs", {}) or {}
            res = r.get("result", {}) or {}
            sample = res.get("partial_unexpected_list")
            if isinstance(sample, list):
                sample = sample[:5]
            fails.append(
                f"- {cfg.get('expectation_type')} col={kwargs.get('column')} "
                f"unexpected={res.get('unexpected_count')} sample={sample}"
            )
    if fails:
        print("[DQ][FAILURES]\n" + "\n".join(fails))
    else:
        print("[DQ] Nenhuma falha detalhada na lista de resultados.")

def _raise_if_failed(result, s3, s3_key_json=None):
    """
    Salva JSON no S3 e decide se falha o DAG baseado na Variable DQ_STRICT.
    Por padrão, NÃO falha (DQ_STRICT=false), apenas loga as falhas.
    """
    from airflow.models import Variable
    import json, io as _io

    # Normaliza objeto do GE
    if hasattr(result, "success"):
        success = bool(result.success)
        payload = result.to_json_dict() if hasattr(result, "to_json_dict") else {}
    else:
        payload = dict(result)
        success = payload.get("success", False)

    # Salva relatório
    if (s3_key_json is not None) and isinstance(payload, dict):
        buf = _io.BytesIO(json.dumps(payload, ensure_ascii=False).encode("utf-8"))
        s3.load_bytes(buf.getvalue(), key=s3_key_json, bucket_name=S3_BUCKET, replace=True)
        print(f"[DQ] Relatório em s3://{S3_BUCKET}/{s3_key_json}")

    # Loga detalhes
    _log_ge_failures(payload if isinstance(payload, dict) else {})

    # Decide se falha
    strict = str(Variable.get("DQ_STRICT", default_var="false")).strip().lower() in {"1","true","y","yes","on"}
    if not success:
        if strict:
            from airflow.exceptions import AirflowException
            raise AirflowException("Falha na validação de qualidade de dados (Great Expectations).")
        else:
            print("[DQ][WARNING] Falhas detectadas, mas DQ_STRICT=false — prosseguindo.")

# =========================================================
# Tasks
# =========================================================
def copy_raw_to_trusted(**context):
    s3 = S3Hook(aws_conn_id="aws_default")
    raw_keys = s3.list_keys(bucket_name=S3_BUCKET, prefix=RAW_PREFIX) or []
    created = []
    for k in raw_keys:
        rel = k[len(RAW_PREFIX):] if k.startswith(RAW_PREFIX) else k
        dst = f"{TRUSTED_PREFIX}{rel}"
        if _move_or_copy(s3, S3_BUCKET, k, dst, overwrite=OVERWRITE_TRUSTED):
            created.append(dst)
    context["ti"].xcom_push(key="trusted_new_keys", value=created)

def build_banks_trusted(**context):
    s3 = S3Hook(aws_conn_id="aws_default")
    src_key = f"{RAW_PREFIX}EnquadramentoInicia_v2.tsv"
    obj = s3.get_key(src_key, bucket_name=S3_BUCKET)
    body = obj.get()["Body"].read()
    buf = io.BytesIO(body)
    df_bancos = pd.read_csv(buf, sep="\t", encoding="utf-8")

    rename_map = {}
    for col in df_bancos.columns:
        if col.lower() == "segmento":
            rename_map[col] = "Segmento_Bancos"
        if col.lower() == "cnpj":
            rename_map[col] = "CNPJ_Bancos"
        if col.lower() == "nome":
            rename_map[col] = "Nome_Bancos"

    df_bancos = df_bancos.rename(columns=rename_map)
    if "CNPJ_Bancos" in df_bancos.columns:
        df_bancos["CNPJ_Bancos"] = df_bancos["CNPJ_Bancos"].apply(trata_documento)

    out_key = f"{TRUSTED_PREFIX}base_bancos_TRUSTED.parquet"
    out_buf = io.BytesIO()
    df_bancos.to_parquet(out_buf, engine="pyarrow", index=False)
    s3.load_bytes(out_buf.getvalue(), key=out_key, bucket_name=S3_BUCKET, replace=True)

    print(f"[BANCOS] Arquivo Parquet salvo em s3://{S3_BUCKET}/{out_key}")
    context["ti"].xcom_push(key="trusted_bancos_key", value=out_key)

def build_employees_trusted(**context):
    s3 = S3Hook(aws_conn_id="aws_default")
    files = [
        f"{RAW_PREFIX}glassdoor_consolidado_join_match_v2.csv",
        f"{RAW_PREFIX}glassdoor_consolidado_join_match_less_v2.csv"
    ]
    dfs = []
    for f in files:
        obj = s3.get_key(f, bucket_name=S3_BUCKET)
        body = obj.get()["Body"].read()
        buf = io.BytesIO(body)
        df = pd.read_csv(buf, delimiter="|")
        dfs.append(df)
        print(f"[EMPREGADOS] {f} -> {len(df)} linhas | Colunas: {list(df.columns)}")

    df1, df2 = dfs

    bancos_key = context["ti"].xcom_pull(key="trusted_bancos_key", task_ids="build_banks_trusted")
    obj = s3.get_key(bancos_key, bucket_name=S3_BUCKET)
    body = obj.get()["Body"].read()
    buf = io.BytesIO(body)
    df_bancos = pd.read_parquet(buf, engine="pyarrow")

    col_candidatos = ["nome", "Nome", "empresa", "Empresa"]
    col_esquerda = next((c for c in col_candidatos if c in df1.columns), None)
    if not col_esquerda:
        raise ValueError(f"[EMPREGADOS] Nenhuma coluna de nome encontrada. Colunas: {list(df1.columns)}")

    df_main  = fuzzy_join(df1, df_bancos, col_esquerda=col_esquerda, col_direita="Nome_Bancos", threshold=100)
    df_main2 = fuzzy_join(df2, df_bancos, col_esquerda=col_esquerda, col_direita="Nome_Bancos", threshold=100)

    if "CNPJ_Bancos" in df_main.columns:
        df_main = df_main.rename(columns={"CNPJ_Bancos": "cnpj"}).drop(columns=["Segmento_Bancos"], errors="ignore")
    if "Segmento_Bancos" in df_main2.columns:
        df_main2 = df_main2.rename(columns={"Segmento_Bancos": "segmento"}).drop(columns=["CNPJ_Bancos"], errors="ignore")

    df_main = pd.concat([df_main, df_main2], ignore_index=True)
    if "cnpj" in df_main.columns:
        df_main["cnpj"] = df_main["cnpj"].apply(trata_documento)

    out_key = f"{TRUSTED_PREFIX}base_empregados_TRUSTED.parquet"
    out_buf = io.BytesIO()
    df_main.to_parquet(out_buf, engine="pyarrow", index=False)
    s3.load_bytes(out_buf.getvalue(), key=out_key, bucket_name=S3_BUCKET, replace=True)

    print(f"[EMPREGADOS] Arquivo salvo em s3://{S3_BUCKET}/{out_key}")
    context["ti"].xcom_push(key="trusted_empregados_key", value=out_key)

def build_reclamacoes_trusted(**context):
    import io, re, unicodedata
    import numpy as np
    import pandas as pd
    from airflow.providers.amazon.aws.hooks.s3 import S3Hook

    s3 = S3Hook(aws_conn_id="aws_default")
    tabelas = [
        "2021_tri_01.csv","2021_tri_02.csv","2021_tri_03.csv",
        "2021_tri_04.csv","2022_tri_01.csv","2022_tri_03.csv","2022_tri_04.csv"
    ]

    # ---------- helpers ----------
    def _read_csv_resiliente(raw_bytes: bytes) -> pd.DataFrame:
        for enc in ("utf-8", "latin1"):
            for sep in (",", ";", "|", "\t"):
                try:
                    buf = io.BytesIO(raw_bytes)
                    df = pd.read_csv(
                        buf, encoding=enc, sep=sep, engine="python",
                        on_bad_lines="warn"
                    )
                    if df.shape[1] > 1:
                        print(f"[READ] encoding={enc} sep={repr(sep)} colunas={list(df.columns)[:6]}...")
                        return df
                except UnicodeDecodeError:
                    continue
                except pd.errors.ParserError:
                    continue
        buf = io.BytesIO(raw_bytes)
        return pd.read_csv(buf, engine="python", on_bad_lines="warn")

    def _replace_dashes_and_trim(col: str) -> str:
        col2 = re.sub(r"[\u2013\u2014\x96]", "-", col)
        col2 = re.sub(r"\s+", " ", col2).strip()
        return col2

    def _unaccent(s: str) -> str:
        return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))

    def _normalize_cols(df: pd.DataFrame) -> pd.DataFrame:
        df = df.rename(columns=lambda c: _replace_dashes_and_trim(str(c)))
        mapping = {}
        for c in df.columns:
            c_clean = _unaccent(c).lower().strip().replace(" ", "_")
            if c_clean in {"instituicao_financeira", "instituicao_financeira_"}:
                mapping[c] = "instituição_financeira"
            elif c_clean in {"cnpj_if", "cnpjif"}:
                mapping[c] = "cnpj_if"
        if mapping:
            df = df.rename(columns=mapping)
        return df

    def _coerce_types(df: pd.DataFrame) -> pd.DataFrame:
        to_drop = [c for c in df.columns if str(c).lower().startswith("unnamed")]
        if to_drop:
            df = df.drop(columns=to_drop)

        if "instituição_financeira" not in df.columns:
            raise ValueError(f"[RECLAMAÇÕES] Coluna 'instituição_financeira' ausente. Colunas: {list(df.columns)}")
        if "cnpj_if" not in df.columns:
            df["cnpj_if"] = " "

        df["cnpj_if"] = (
            df["cnpj_if"]
            .astype(str)
            .str.replace(r"[^\d]", "", regex=True)
        )

        for col in df.columns:
            base = _unaccent(col).strip().lower()
            if base == "indice":
                s = (
                    df[col]
                    .astype(str)
                    .str.replace(",", ".", regex=False)
                    .str.replace(r"[^\d\.\-eE]", "", regex=True)
                )
                df[col] = pd.to_numeric(s, errors="coerce")

        def _is_quantidade(colname: str) -> bool:
            return _unaccent(colname).strip().lower().startswith("quantidade")

        quantidade_cols = [c for c in df.columns if _is_quantidade(c)]
        for c in quantidade_cols:
            s = df[c].astype(str).str.replace(r"[^\d-]", "", regex=True)
            df[c] = pd.to_numeric(s, errors="coerce").fillna(0).astype("Int64")

        if "Ano" in df.columns:
            df["Ano"] = pd.to_numeric(df["Ano"], errors="coerce").astype("Int64")

        return df

    # ---------- leitura & concat ----------
    frames = []
    for t in tabelas:
        key = f"{RAW_PREFIX}{t}"
        obj = s3.get_key(key, bucket_name=S3_BUCKET)
        raw = obj.get()["Body"].read()
        df = _read_csv_resiliente(raw)
        df = _normalize_cols(df)
        print(f"[RECLAMAÇÕES] {t}: {len(df)} linhas | colunas={list(df.columns)}")
        frames.append(df)

    df2 = pd.concat(frames, ignore_index=True)
    df2 = _coerce_types(df2)

    # split pronto/não-pronto
    df_ready  = df2[df2["cnpj_if"] != ""].copy()
    df_nready = df2[df2["cnpj_if"] == ""].drop(columns=["cnpj_if"], errors="ignore")

    # auxiliar para fuzzy
    df_aux = df2[["instituição_financeira", "cnpj_if"]]
    df_aux = df_aux[df_aux["cnpj_if"] == ""].drop_duplicates()

    # carrega bancos trusted
    bancos_key = context["ti"].xcom_pull(key="trusted_bancos_key", task_ids="build_banks_trusted")
    obj = s3.get_key(bancos_key, bucket_name=S3_BUCKET)
    ref = obj.get()["Body"].read()
    df_bancos = pd.read_parquet(io.BytesIO(ref), engine="pyarrow")

    # fuzzy join
    df_merge = fuzzy_join(
        df_aux, df_bancos,
        col_esquerda="instituição_financeira",
        col_direita="Nome_Bancos",
        threshold=100
    )

    # detecta coluna de CNPJ vinda com/sem prefixo ref_
    if "ref_CNPJ_Bancos" in df_merge.columns:
        cnpj_col = "ref_CNPJ_Bancos"
    elif "CNPJ_Bancos" in df_merge.columns:
        cnpj_col = "CNPJ_Bancos"
    else:
        raise ValueError(f"[RECLAMAÇÕES] Não achei coluna de CNPJ após o fuzzy_join. Colunas: {list(df_merge.columns)}")

    df_merge = (
        df_merge[["instituição_financeira", cnpj_col]]
        .rename(columns={cnpj_col: "cnpj_if"})
    )
    df_merge["cnpj_if"] = df_merge["cnpj_if"].astype(str).str.replace(r"[^\d]", "", regex=True)

    # merge + concat final
    df_nready = df_nready.merge(df_merge, how="left", on=["instituição_financeira"])
    df_main_2 = pd.concat([df_ready, df_nready], ignore_index=True)

    if "cnpj_if" in df_main_2.columns:
        df_main_2["cnpj_if"] = df_main_2["cnpj_if"].apply(trata_documento)

    df_main_2 = df_main_2.convert_dtypes()

    # ---------- salva parquet no trusted ----------
    out_key = f"{TRUSTED_PREFIX}base_reclamacoes_TRUSTED.parquet"
    out_buf = io.BytesIO()
    df_main_2.to_parquet(out_buf, engine="pyarrow", index=False)
    s3.load_bytes(out_buf.getvalue(), key=out_key, bucket_name=S3_BUCKET, replace=True)
    print(f"[RECLAMAÇÕES] Arquivo salvo em s3://{S3_BUCKET}/{out_key}")

    # chave para delivered
    context["ti"].xcom_push(key="trusted_reclamacoes_key", value=out_key)

def build_delivered_join(**context):
    import io
    import pandas as pd
    from airflow.providers.amazon.aws.hooks.s3 import S3Hook

    s3 = S3Hook(aws_conn_id="aws_default")

    # Chaves do trusted produzidas pelas tasks anteriores
    emp_key  = context["ti"].xcom_pull(key="trusted_empregados_key", task_ids="build_employees_trusted")
    rec_key  = context["ti"].xcom_pull(key="trusted_reclamacoes_key", task_ids="build_reclamacoes_trusted")

    if not emp_key or not rec_key:
        raise ValueError("[DELIVERED_JOIN] Chaves do trusted ausentes (empregados/reclamações).")

    # Lê Parquets do trusted
    obj_emp = s3.get_key(emp_key, bucket_name=S3_BUCKET)
    df_main = pd.read_parquet(io.BytesIO(obj_emp.get()["Body"].read()), engine="pyarrow")

    obj_rec = s3.get_key(rec_key, bucket_name=S3_BUCKET)
    df_main_2 = pd.read_parquet(io.BytesIO(obj_rec.get()["Body"].read()), engine="pyarrow")

    # -------- Normaliza chaves de junção --------
    # Detecta coluna de CNPJ em df_main (empregados)
    candidatos_emp = ["cnpj", "CNPJ", "ref_CNPJ_Bancos", "CNPJ_Bancos"]
    emp_cnpj_col = next((c for c in candidatos_emp if c in df_main.columns), None)
    if not emp_cnpj_col:
        raise ValueError(f"[DELIVERED_JOIN] Não encontrei coluna de CNPJ em empregados. Colunas: {list(df_main.columns)}")

    # Detecta coluna de CNPJ em df_main_2 (reclamações)
    rec_cnpj_col = "cnpj_if" if "cnpj_if" in df_main_2.columns else None
    if not rec_cnpj_col:
        raise ValueError(f"[DELIVERED_JOIN] 'cnpj_if' ausente em reclamações. Colunas: {list(df_main_2.columns)}")

    # Padroniza para coluna 'cnpj' nos dois lados (14 dígitos)
    df_final_1 = df_main.copy()
    df_final_1["cnpj"] = df_final_1[emp_cnpj_col].map(trata_documento)

    df_final_2 = df_main_2.copy()
    df_final_2 = df_final_2.rename(columns={rec_cnpj_col: "cnpj"})
    df_final_2["cnpj"] = df_final_2["cnpj"].map(trata_documento)

    # Merge final (outer)
    df_join = df_final_1.merge(df_final_2, how="outer", on=["cnpj"])

    # -------- gravações no delivered --------
    # 1) Parquet
    out_parquet_key = f"{DELIVERED_PREFIX}base_master_DELIVERED.parquet"
    buf_parquet = io.BytesIO()
    df_join.to_parquet(buf_parquet, engine="pyarrow", index=False)
    out_parquet_key = _put_versioned_or_overwrite(
        s3, S3_BUCKET, out_parquet_key, buf_parquet.getvalue(), OVERWRITE_DELIVERED
    )
    print(f"[DELIVERED_JOIN] Parquet salvo em s3://{S3_BUCKET}/{out_parquet_key}")

    # 2) CSV (StringIO -> bytes)
    out_csv_key = f"{DELIVERED_PREFIX}base_master_DELIVERED.csv"
    import io as _io
    buf_csv_text = _io.StringIO()
    df_join.to_csv(buf_csv_text, index=False)
    out_csv_key = _put_versioned_or_overwrite(
        s3, S3_BUCKET, out_csv_key, buf_csv_text.getvalue().encode("utf-8"), OVERWRITE_DELIVERED
    )
    print(f"[DELIVERED_JOIN] CSV salvo em s3://{S3_BUCKET}/{out_csv_key}")

    # XComs de saída
    context["ti"].xcom_push(key="delivered_master_parquet_key", value=out_parquet_key)
    context["ti"].xcom_push(key="delivered_master_csv_key", value=out_csv_key)

def dq_validate_reclamacoes_trusted(**context):
    # Se GE não estiver instalado, apenas loga e segue VERDE
    try:
        import great_expectations  # noqa: F401
    except ImportError:
        print("[DQ] great_expectations não instalado. Prosseguindo sem validação (reclamações).")
        return

    import io
    import pandas as pd
    from airflow.providers.amazon.aws.hooks.s3 import S3Hook
    import pendulum

    s3 = S3Hook(aws_conn_id="aws_default")
    rec_key = context["ti"].xcom_pull(key="trusted_reclamacoes_key", task_ids="build_reclamacoes_trusted")
    if not rec_key:
        print("[DQ] Chave trusted_reclamacoes_key não encontrada — prosseguindo sem DQ.")
        return

    obj = s3.get_key(rec_key, bucket_name=S3_BUCKET)
    df = pd.read_parquet(io.BytesIO(obj.get()["Body"].read()), engine="pyarrow")

    result = _gx_expectations_for_reclamacoes(df)
    ts = pendulum.now("America/Sao_Paulo").to_datetime_string().replace(":", "-").replace(" ", "_")
    report_key = f"{DELIVERED_PREFIX}quality/reclamacoes_validation_{ts}.json"
    _raise_if_failed(result, s3, s3_key_json=report_key)
    print("[DQ] Reclamações — validação executada.")

def dq_validate_delivered_master(**context):
    # Se GE não estiver instalado, apenas loga e segue VERDE
    try:
        import great_expectations  # noqa: F401
    except ImportError:
        print("[DQ] great_expectations não instalado. Prosseguindo sem validação (master).")
        return

    import io
    import pandas as pd
    from airflow.providers.amazon.aws.hooks.s3 import S3Hook
    import pendulum

    s3 = S3Hook(aws_conn_id="aws_default")
    master_key = context["ti"].xcom_pull(key="delivered_master_parquet_key", task_ids="build_delivered_join")
    if not master_key:
        print("[DQ] Chave delivered_master_parquet_key não encontrada — prosseguindo sem DQ.")
        return

    obj = s3.get_key(master_key, bucket_name=S3_BUCKET)
    df = pd.read_parquet(io.BytesIO(obj.get()["Body"].read()), engine="pyarrow")

    result = _gx_expectations_for_delivered(df)
    ts = pendulum.now("America/Sao_Paulo").to_datetime_string().replace(":", "-").replace(" ", "_")
    report_key = f"{DELIVERED_PREFIX}quality/master_validation_{ts}.json"
    _raise_if_failed(result, s3, s3_key_json=report_key)
    print("[DQ] Master — validação executada.")

def log_pipeline_success(**context):
    p = context["ti"].xcom_pull(key="delivered_master_parquet_key", task_ids="build_delivered_join")
    c = context["ti"].xcom_pull(key="delivered_master_csv_key", task_ids="build_delivered_join")
    print("[SUCCESS] Pipeline executado. Veja mensagens de DQ acima (strict controlado via Variable DQ_STRICT).")
    if p: print(f"[SUCCESS] Parquet final: s3://{S3_BUCKET}/{p}")
    if c: print(f"[SUCCESS] CSV final: s3://{S3_BUCKET}/{c}")

def copy_trusted_to_delivered(**context):
    s3 = S3Hook(aws_conn_id="aws_default")
    keys = []

    bancos_keys = context["ti"].xcom_pull(key="trusted_bancos_key", task_ids="build_banks_trusted") or []
    empregados_keys = context["ti"].xcom_pull(key="trusted_empregados_key", task_ids="build_employees_trusted") or []
    reclamacoes_keys = context["ti"].xcom_pull(key="trusted_reclamacoes_key", task_ids="build_reclamacoes_trusted") or []

    if isinstance(bancos_keys, str):
        bancos_keys = [bancos_keys]
    if isinstance(empregados_keys, str):
        empregados_keys = [empregados_keys]
    if isinstance(reclamacoes_keys, str):
        reclamacoes_keys = [reclamacoes_keys]

    keys.extend(bancos_keys)
    keys.extend(empregados_keys)
    keys.extend(reclamacoes_keys)

    print(f"[DELIVERED] Keys a copiar: {keys}")

    for k in keys:
        rel = k[len(TRUSTED_PREFIX):] if k.startswith(TRUSTED_PREFIX) else os.path.basename(k)
        dst = f"{DELIVERED_PREFIX}{rel}"
        _copy_or_overwrite(s3, S3_BUCKET, k, dst, overwrite=OVERWRITE_DELIVERED)

    print(f"[RESULT] DELIVERED novos/atualizados: {len(keys)}")

# =========================================================
# DAG
# =========================================================
with DAG(
    dag_id="s3_raw_trusted_delivered",
    schedule="@daily",
    start_date=pendulum.datetime(2025, 9, 1, tz="America/Sao_Paulo"),
    catchup=False,
    default_args={"owner": "airflow", "retries": 1, "retry_delay": timedelta(minutes=3)},
    tags=["s3","lake","raw","trusted","delivered","dq"],
) as dag:

    t1 = PythonOperator(
        task_id="copy_raw_to_trusted",
        python_callable=copy_raw_to_trusted,
    )

    t_bancos = PythonOperator(
        task_id="build_banks_trusted",
        python_callable=build_banks_trusted,
    )

    t_empregados = PythonOperator(
        task_id="build_employees_trusted",
        python_callable=build_employees_trusted,
    )

    t_reclamacoes = PythonOperator(
        task_id="build_reclamacoes_trusted",
        python_callable=build_reclamacoes_trusted,
    )

    # DQ: valida trusted de reclamações
    t_dq_reclamacoes = PythonOperator(
        task_id="dq_validate_reclamacoes_trusted",
        python_callable=dq_validate_reclamacoes_trusted,
    )

    t_delivered_join = PythonOperator(
        task_id="build_delivered_join",
        python_callable=build_delivered_join,
    )

    # DQ: valida master do delivered
    t_dq_master = PythonOperator(
        task_id="dq_validate_delivered_master",
        python_callable=dq_validate_delivered_master,
    )

    t_success = PythonOperator(
        task_id="log_pipeline_success",
        python_callable=log_pipeline_success,
    )

    t3 = PythonOperator(
        task_id="copy_trusted_to_delivered",
        python_callable=copy_trusted_to_delivered,
    )

    # Encadeamento com DQ e log final de sucesso
    t1 >> t_bancos >> t_empregados >> t_reclamacoes >> t_dq_reclamacoes >> t_delivered_join >> t_dq_master >> t_success >> t3
