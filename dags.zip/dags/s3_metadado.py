from airflow import DAG
from airflow.operators.python import PythonOperator
import pendulum

def step(msg):
    print(f"[STEP] {msg}")

with DAG(
    dag_id="garantir_metadados",
    start_date=pendulum.datetime(2025, 1, 1, tz="UTC"),
    schedule=None,
    catchup=False,
) as dag:
    t1 = PythonOperator(task_id="raw", python_callable=lambda: step("RAW"))
    t2 = PythonOperator(task_id="trusted", python_callable=lambda: step("TRUSTED"))
    t3 = PythonOperator(task_id="delivered", python_callable=lambda: step("DELIVERED"))
    t1 >> t2 >> t3
